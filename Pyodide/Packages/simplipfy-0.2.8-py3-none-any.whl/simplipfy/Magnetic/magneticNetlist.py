from simplipfy.Magnetic.elements import MagneticElementFkt, MagneticElement
from simplipfy.Magnetic.elements import MagneticCore, Gap, MagnetomotiveForceSource
from typing import TypeVar, Type

T = TypeVar('T', bound=MagneticElement)

class Netlist:
    cpts: list[MagneticElement] = []
    index: dict[str, MagneticElement] = {}

    def append(self, element: MagneticElement):
        self.cpts.append(element)
        self.index[element.componentType + element.identifier] = element

    def filterElems(self, type: Type[T]) -> list[T]:
        return [cpt for cpt in self if isinstance(cpt, type)]

    def __getitem__(self,name:str) -> MagneticElement:
        return self.index[name]

    @property
    def netlist(self) -> str:
        netlist = ""
        for cpt in self.cpts:
            netlist += str(cpt) + "\n"
        return netlist

    def __iter__(self):
        return iter(self.cpts)

    @staticmethod
    def parse(netlist: str) -> 'Netlist':
        fkt = lambda line: MagneticElementFkt.getElement(line)
        lines = netlist.splitlines()
        netlist = Netlist()

        for line in lines:
            netlist.append(fkt(line))

        return netlist
