from simplipfy.Magnetic.elements import MagneticElementFkt, MagneticElement
from simplipfy.Magnetic.elements import MagneticCore, Gap, MagnetomotiveForceSource

class Netlist:
    cpts: list[MagneticElement] = []

    def append(self, element: MagneticElement):
        self.cpts.append(element)

    def filterElems(self, types: tuple[type[MagneticElement]]) -> list[MagneticElement]:
        return [cpt for cpt in self if isinstance(cpt, types)]

    @property
    def cores(self) -> list[MagneticCore]:
        return self.filterElems((MagneticCore,))

    @property
    def gaps(self) -> list[Gap]:
        return self.filterElems((Gap,))

    @property
    def sources(self) -> list[MagnetomotiveForceSource]:
        return self.filterElems((MagnetomotiveForceSource,))

    @property
    def netlist(self) -> str:
        netlist = ""
        for cpt in self.cpts:
            netlist += str(cpt) + "\n"
        return netlist

    def __iter__(self):
        return iter(self.cpts)

    @staticmethod
    def parse(netlist: str) -> 'Netlist':
        fkt = lambda line: MagneticElementFkt.getElement(line)
        lines = netlist.splitlines()
        netlist = Netlist()

        for line in lines:
            netlist.append(fkt(line))

        return netlist
