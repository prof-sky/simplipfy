from simpliPFyBuildTools.getAbsPath import getAbsPath
from simplipfy.Magnetic.elements import MagneticElement, MagneticElementFkt
from simplipfy.Magnetic.magneticNetlist import Netlist
f = open("test.txt", "r")
netlist = Netlist().parse(f.read())
f.close()

a= netlist.cpts[0].mr

pass