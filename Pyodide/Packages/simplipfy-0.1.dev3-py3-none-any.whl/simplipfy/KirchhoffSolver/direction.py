from enum import Enum

class Direction(Enum):
    counterClockwise = 0
    clockwise = 1