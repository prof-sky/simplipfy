class AdmittanceSquaredMixin(object):

    quantity = 'admittancesquared'
    quantity_label = 'Admittance^2'
    quantity_units = 'S^2'
    is_admittancesquared = True
    is_squared = True
    is_ratio = True
