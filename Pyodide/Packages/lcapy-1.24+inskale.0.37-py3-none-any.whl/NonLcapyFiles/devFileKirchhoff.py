import solve

test = solve.KirchhoffSolver.makeDummy()
a = test.checkVoltageLoopRule()
b = test.checkJunctionRule()
print(test)