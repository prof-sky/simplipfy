class JsonExport:
    def __init__(self, thisStep, lastStep):
        return
