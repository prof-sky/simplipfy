from NonLcapyFiles.solve import solve_circuit, SolveInUserOrder
import os
from lcapy.dictExport import ExportDict
import pytest
import random

# string is filename, integer is number of steps that shall be created
# the initial step has to be included
filenames = [("capacitor/07_capacitors_mixed_simple.txt", 5),
             ("inductor/08_inductors_mixed_simple.txt", 5),
             ("mixed/Circuit_mixed_30.txt", 5),
             ("mixed/Circuit_mixed_2pi30.txt", 5),
             ("resistor/04_resistor_mixed_simple.txt", 5)]


def clearDir(path):
    if os.path.exists(path) and os.path.isdir(path):
        toRemove = os.listdir(path)
        for remove in toRemove:
            os.remove(os.path.join(path, remove))


def check_for_solutions(solSteps: int, filename: str, path: str = "../Solutions", filesPerStep: int = 2):
    # each step produces 2 json files and 1 svg file
    assert len(os.listdir(path)) == solSteps*filesPerStep, f"{filename} didn't produce as many files as expected"


def solveInUserOrder(filename):
    clearDir("../Solutions")

    test = SolveInUserOrder(filename=filename, filePath="../Circuits/")
    ExportDict.set_paths(savePath="../Solutions/", fileName=filename)

    test.createInitialStep().toFiles()
    test.simplifyNCpts(["Z4", "Z5"]).toFiles()
    test.simplifyNCpts(["Z1", "Zs1"]).toFiles()
    test.simplifyNCpts(["Z2", "Z3"]).toFiles()
    test.simplifyNCpts(["Zs2", "Zs3"]).toFiles()


def generate_solve_circuit_fileNames() -> list:
    allFiles = []
    for root, _, files in os.walk("../Circuits"):
        for file in files:
            if file.endswith(".txt"):
                allFiles.append(os.path.join(root, file))
    return allFiles

@pytest.mark.parametrize("absFilePath", generate_solve_circuit_fileNames())
def test_solve_circuits(absFilePath):
    clearDir("../Solutions")
    filePath = os.path.dirname(absFilePath)
    filename = os.path.basename(absFilePath)
    solve_circuit(filename, filePath=filePath, savePath="../Solutions")
    steps = len(SolveInUserOrder(filename=filename, filePath=filePath).createInitialStep()["allComponents"])
    check_for_solutions(filename=filename, solSteps=steps)


def test_SolveInUserOrder():
    for filename in filenames:
        clearDir("../Solutions")
        solveInUserOrder(filename[0])
        check_for_solutions(filename=filename[0], solSteps=filename[1])
        print(f"{filename[0]+'...':40s}success")