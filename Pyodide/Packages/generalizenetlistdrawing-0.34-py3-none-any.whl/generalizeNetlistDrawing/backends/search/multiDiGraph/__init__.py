from .findParallelNodes import FindParallelNodes
from .findSeriesNodes import FindSeriesNodes

findRowNodesSequence = FindSeriesNodes.findSeriesNodesSequence
findParallelNode = FindParallelNodes.findParallelNode