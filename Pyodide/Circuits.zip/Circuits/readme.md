The content of this folder (Circuits) and the corresponding Circuits.zip folder
are not under any license and can be used and adapted freely. 
There is no need for any publication of the source code if you adapt the Circuits to your needs.